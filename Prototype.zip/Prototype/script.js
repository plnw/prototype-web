// Sample Game Database
const games = [
    { "id": 1, "name": "Adventure Quest", "price": 29.99, "creatorName": "John Anderson", "status": "Approved" },
    { "id": 2, "name": "Space Battle", "price": 49.99, "description": "Intense multiplayer battle game", "creatorName": "John Anderson", "status": "Approved" },
];

const credentials = {
    user: { username: "user1", password: "1111" },
    creator: { username: "creator1", password: "1111111" },
    admin: { username: "admin1", password: "11111" }
};

let cart = [];
let uploadedGames = [];
let currentUserRole = null;
let selectedRole = null;

function showHomePage() {
    document.getElementById("user-section").style.display = "none";
    document.getElementById("creator-section").style.display = "none";
    document.getElementById("admin-section").style.display = "none";
    document.getElementById("homepage").style.display = "block";
    currentUserRole = null;
}

function showSection(sectionId) {
    document.getElementById("homepage").style.display = "none";
    document.getElementById("user-section").style.display = "none";
    document.getElementById("creator-section").style.display = "none";
    document.getElementById("admin-section").style.display = "none";
    document.getElementById(sectionId).style.display = "block";

    if (sectionId === "user-section") {
        loadGames();
        loadCart();
    } else if (sectionId === "creator-section") {
        loadUploadedGames();
    } else if (sectionId === "admin-section") {
        loadPendingGames();
    }
}

function login(role) {
    currentUserRole = role;
    if (role === "user") showSection("user-section");
    else if (role === "creator") showSection("creator-section");
    else if (role === "admin") showSection("admin-section");
    document.getElementById("account-menu").style.display = "none";
}

function logout() {
    currentUserRole = null;
    showHomePage();
}

function toggleAccountMenu() {
    const menu = document.getElementById("account-menu");
    menu.style.display = menu.style.display === "none" ? "block" : "none";
}

function openLoginModal(role) {
    selectedRole = role;
    document.getElementById("login-modal").style.display = "block";
}

function closeLoginModal() {
    document.getElementById("login-modal").style.display = "none";
}

function showMessageModal(message) {
    document.getElementById("message-text").innerText = message;
    document.getElementById("message-modal").style.display = "block";
}

function closeMessageModal() {
    document.getElementById("message-modal").style.display = "none";
}

function submitLogin() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (credentials[selectedRole] && credentials[selectedRole].username === username && credentials[selectedRole].password === password) {

        closeLoginModal();
        showMessageModal("Login successful!");

        setTimeout(() => {
            closeMessageModal();
            login(selectedRole);
        }, 1000);
    } else {
        showMessageModal("Login failed! Incorrect username or password.");
        setTimeout(() => {
            closeMessageModal();
        }, 2000);
    }
}

// Functions for User Section
function loadGames() {
    const gameList = document.getElementById("game-list");
    gameList.innerHTML = '';

    games.filter(game => game.status === "Approved").forEach(game => {
        const gameDiv = document.createElement("div");
        gameDiv.classList.add("game-item");

        gameDiv.innerHTML = `
            <h3>${game.name}</h3>
            <p><strong>Price:</strong> $${game.price}</p>
            <p><strong>Description:</strong> ${game.description}</p>
            <p><strong>Created By:</strong> ${game.creatorName}</p>
            <button onclick="addToCart('${game.name}')">Add to Cart</button>
        `;

        gameList.appendChild(gameDiv);
    });
}

function addToCart(gameName) {
    console.log("Trying to add game with Name:", gameName);

    const game = games.find(g => g.name === gameName && g.status === "Approved");

    if (game) {
        const isAlreadyInCart = cart.some(item => item.name === game.name);

        if (!isAlreadyInCart) {
            cart.push(game);
            alert(`${game.name} has been added to your cart.`);
        } else {
            alert(`${game.name} is already in your cart.`);
        }
    } else {
        alert("This game is not available for purchase.");
    }

    loadCart();
}

function loadCart() {
    const cartList = document.getElementById("cart-list");
    cartList.innerHTML = '';

    cart.forEach(item => {
        const li = document.createElement("li");
        li.innerHTML = `${item.name} - $${item.price} <button onclick="removeFromCart('${item.name}')">Remove</button>`;
        cartList.appendChild(li);
    });
}

function removeFromCart(gameName) {
    const index = cart.findIndex(item => item.name === gameName);
    if (index !== -1) {
        const removedItem = cart.splice(index, 1)[0];
        alert(`${removedItem.name} has been removed from your cart.`);
        loadCart();
    }
}

// Function to view the cart section
function viewCart() {
    document.getElementById("game-section").style.display = "none";
    document.getElementById("cart-section").style.display = "block";
    loadCart();
}

document.getElementById("view-cart").addEventListener("click", viewCart);

function showGames() {
    document.getElementById("cart-section").style.display = "none";
    document.getElementById("game-section").style.display = "block";
}

document.querySelector("#cart-section button").addEventListener("click", showGames);

// Functions for Game Creator Section
function createGame() {
    const name = document.getElementById("game-name").value;
    const description = document.getElementById("game-description").value;
    const gameFile = document.getElementById("game-file").value;
    const price = parseFloat(document.getElementById("game-price").value);
    const creatorName = document.getElementById("creator-name").value;

    if (name && description && gameFile && !isNaN(price) && creatorName) {
        currentGame = {
            id: uploadedGames.length + 1,
            name: name,
            description: description,
            gameFile: gameFile,
            price: price,
            creatorName: creatorName,
            status: "Pending"
        };
        alert(`Game details for "${name}" have been saved. Now add requirements.`);
        clearGameDetailInputs();
    } else {
        alert("Please fill out all fields correctly in game details.");
    }
}

// Add Game Requirements
function addGameRequirements() {
    const os = document.getElementById("game-os").value;
    const hardware = document.getElementById("game-hardware").value;
    const ageRating = document.getElementById("game-age-rating").value;
    const rating = parseFloat(document.getElementById("game-rating").value);

    if (os && hardware && ageRating && !isNaN(rating)) {
        currentGame.requirements = {
            os: os,
            hardware: hardware,
            ageRating: ageRating,
            rating: rating
        };

        uploadedGames.push(currentGame);
        alert(`Game "${currentGame.name}" with requirements has been submitted for approval.`);
        clearRequirementsInputs();
        loadUploadedGames();
    } else {
        alert("Please fill out all fields correctly in game requirements.");
    }
}

function clearGameDetailInputs() {
    document.getElementById("game-name").value = '';
    document.getElementById("game-description").value = '';
    document.getElementById("game-file").value = '';
    document.getElementById("game-price").value = '';
    document.getElementById("creator-name").value = '';
}

function clearRequirementsInputs() {
    document.getElementById("game-os").value = '';
    document.getElementById("game-hardware").value = '';
    document.getElementById("game-age-rating").value = '';
    document.getElementById("game-rating").value = '';
}

function loadUploadedGames() {
    const uploadedGamesList = document.getElementById("uploaded-games-list");
    uploadedGamesList.innerHTML = '';

    uploadedGames.forEach(game => {
        const li = document.createElement("li");

        li.innerHTML = `
            <strong>${game.name}</strong><br>
            <strong>Description:</strong> ${game.description}<br>
            <strong>Game File:</strong> <a href="${game.gameFile}" target="_blank">Download or View</a><br>
            <strong>Price:</strong> $${game.price}<br>
            <strong>Creator:</strong> ${game.creatorName}<br>
            <strong>Status:</strong> ${game.status}<br>
        `;

        if (game.requirements) {
            li.innerHTML += `
                <br><strong>Requirements:</strong><br>
                <strong>OS:</strong> ${game.requirements.os || 'N/A'}<br>
                <strong>Hardware:</strong> ${game.requirements.hardware || 'N/A'}<br>
                <strong>Age Rating:</strong> ${game.requirements.ageRating || 'N/A'}<br>
                <strong>Rating:</strong> ${game.requirements.rating || 'N/A'}<br>
            `;
        }

        uploadedGamesList.appendChild(li);
    });
}

function loadGamesForUser() {
    const gameList = document.getElementById("game-list");
    gameList.innerHTML = '';

    games.forEach(game => {
        const li = document.createElement("li");

        li.innerHTML = `
            <strong>${game.name}</strong><br>
            Description: ${game.description}<br>
            Game File: <a href="${game.gameFile}" target="_blank">Download or View</a><br>
            Price: $${game.price}<br>
            Creator: ${game.creatorName}<br>
            Status: ${game.status}<br>  <!-- Display status to users -->
        `;

        if (game.requirements) {
            li.innerHTML += `
                <br><strong>Requirements:</strong><br>
                OS: ${game.requirements.os || 'N/A'}<br>
                Hardware: ${game.requirements.hardware || 'N/A'}<br>
                Age Rating: ${game.requirements.ageRating || 'N/A'}<br>
                Rating: ${game.requirements.rating || 'N/A'}<br>
            `;
        }

        gameList.appendChild(li);
    });
}

function loadPendingGames() {
    const pendingGamesList = document.getElementById("pending-games-list");
    pendingGamesList.innerHTML = '';

    uploadedGames.filter(game => game.status === "Pending").forEach(game => {
        const li = document.createElement("li");

        li.innerHTML = `
            <strong>${game.name}</strong><br>
            Description: ${game.description}<br>
            Game File: <a href="${game.gameFile}" target="_blank">Download or View</a><br>
            Price: $${game.price}<br>
            Creator: ${game.creatorName}<br>
            Status: ${game.status}<br>
        `;

        if (game.requirements) {
            li.innerHTML += `
                <br><strong>Requirements:</strong><br>
                OS: ${game.requirements.os || 'N/A'}<br>
                Hardware: ${game.requirements.hardware || 'N/A'}<br>
                Age Rating: ${game.requirements.ageRating || 'N/A'}<br>
                Rating: ${game.requirements.rating || 'N/A'}<br>
            `;
        }

        li.innerHTML += `
            <button onclick="approveGame(${game.id})">Approve</button>
            <button onclick="rejectGame(${game.id})">Reject</button>
        `;

        pendingGamesList.appendChild(li);
    });
}

function approveGame(gameId) {
    const gameIndex = uploadedGames.findIndex(g => g.id === gameId);
    if (gameIndex !== -1) {
        const game = uploadedGames[gameIndex];
        game.status = "Approved";

        games.push({ ...game });

        uploadedGames.splice(gameIndex, 1);

        alert(`${game.name} has been approved!`);
        alert(`Your game "${game.name}" has been Approved by the admin.`);

        loadPendingGames();
        loadGames();
        loadUploadedGames();
    }
}

function rejectGame(gameId) {
    const gameIndex = uploadedGames.findIndex(g => g.id === gameId);
    if (gameIndex !== -1) {
        const game = uploadedGames[gameIndex];
        game.status = "Rejected";

        uploadedGames.splice(gameIndex, 1);

        alert(`${game.name} has been rejected.`);
        alert(`Your game "${game.name}" has been Rejected by the admin.`);

        loadPendingGames();
        loadUploadedGames();
    }
}

// Notify the game creator about approval/rejection
function sendGameStatusToCreator(game, status) {
    const gameIndex = uploadedGames.findIndex(g => g.id === game.id);
    if (gameIndex !== -1) {
        uploadedGames[gameIndex].status = status;
    }

    alert(`Your game "${game.name}" has been ${status} by the admin.`);

    loadUploadedGames();
}

// Initialize Homepage view by default
window.onload = function () {
    showHomePage();
};
